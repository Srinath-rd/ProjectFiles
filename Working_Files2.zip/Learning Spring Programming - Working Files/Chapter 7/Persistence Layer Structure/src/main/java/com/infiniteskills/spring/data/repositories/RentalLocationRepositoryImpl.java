package com.infiniteskills.spring.data.repositories;

import com.infiniteskills.spring.data.entities.RentalLocation;

public class RentalLocationRepositoryImpl implements RentalLocationRepository {
		
	public void insert(RentalLocation entity) {
		// TODO Auto-generated method stub
	}

	public void update(RentalLocation entity) {
		// TODO Auto-generated method stub

	}

	public void delete(RentalLocation entity) {
		// TODO Auto-generated method stub

	}

	public RentalLocation findById() {
		// TODO Auto-generated method stub
		return null;
	}

}
