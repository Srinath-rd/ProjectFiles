package com.infiniteskills.spring.data.services;

import com.infiniteskills.spring.data.repositories.RentalLocationRepository;

public class RentalService {

	RentalLocationRepository repository;
	
	public void rent() {
		
	}
}
