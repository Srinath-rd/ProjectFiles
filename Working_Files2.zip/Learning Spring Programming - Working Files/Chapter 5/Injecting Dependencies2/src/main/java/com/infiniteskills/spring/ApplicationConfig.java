package com.infiniteskills.spring;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.infiniteskills.spring")
public class ApplicationConfig {


}
