package com.infiniteskills.spring;

public class BeanB {

	private BeanC beanC;

	public BeanC getBeanC() {
		return beanC;
	}

	public void setBeanC(BeanC beanC) {
		this.beanC = beanC;
	}

}
