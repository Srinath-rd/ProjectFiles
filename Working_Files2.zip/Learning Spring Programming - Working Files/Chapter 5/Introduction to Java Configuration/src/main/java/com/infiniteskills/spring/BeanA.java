package com.infiniteskills.spring;

public class BeanA {

	public void execute() {
		System.out.println("Hello Java Configuration!");
	}
}
