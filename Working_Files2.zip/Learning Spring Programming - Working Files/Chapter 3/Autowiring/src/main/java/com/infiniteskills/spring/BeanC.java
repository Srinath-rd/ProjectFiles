package com.infiniteskills.spring;

public class BeanC {

	public BeanC() {
		System.out.println("Constructor Called: public BeanC()");
	}
}
