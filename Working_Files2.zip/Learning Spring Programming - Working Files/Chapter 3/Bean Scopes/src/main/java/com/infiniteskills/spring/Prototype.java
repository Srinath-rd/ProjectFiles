package com.infiniteskills.spring;

public class Prototype {
	
	public void execute() {
		System.out.println("Execute Method Called");
	}
}
