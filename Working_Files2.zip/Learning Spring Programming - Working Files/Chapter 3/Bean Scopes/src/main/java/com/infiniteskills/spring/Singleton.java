package com.infiniteskills.spring;

public class Singleton {

	private Prototype beanB;

	public Prototype getBeanB() {
		return beanB;
	}
}
