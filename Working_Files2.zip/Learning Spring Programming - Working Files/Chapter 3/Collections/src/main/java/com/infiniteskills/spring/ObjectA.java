package com.infiniteskills.spring;

public class ObjectA {

}
