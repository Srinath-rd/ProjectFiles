package com.infiniteskills.spring;

public class BeanB {
	
	public void execute() {
		System.out.println("Execute Method Called");
	}
}
