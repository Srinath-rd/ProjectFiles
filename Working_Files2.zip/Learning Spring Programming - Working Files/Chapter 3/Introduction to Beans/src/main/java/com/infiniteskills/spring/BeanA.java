package com.infiniteskills.spring;

public class BeanA {

	public BeanA() {
		System.out.println("Spring instantiated Me");
	}
	
}
