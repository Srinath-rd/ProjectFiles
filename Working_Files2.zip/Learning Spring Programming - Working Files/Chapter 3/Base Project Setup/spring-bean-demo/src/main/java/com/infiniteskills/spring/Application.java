package com.infiniteskills.spring;

public class Application {

	public static void main(String[] args) {
		
	}
}
