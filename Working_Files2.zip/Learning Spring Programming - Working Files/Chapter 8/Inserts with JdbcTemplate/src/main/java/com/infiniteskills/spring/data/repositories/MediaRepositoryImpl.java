package com.infiniteskills.spring.data.repositories;

import com.infiniteskills.spring.data.entities.Media;

public class MediaRepositoryImpl implements MediaRepository {

	public void insert(Media entity) {
		// TODO Auto-generated method stub
	}

	public void update(Media entity) {
		// TODO Auto-generated method stub

	}

	public void delete(Media entity) {
		// TODO Auto-generated method stub

	}

	public Media findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

}
