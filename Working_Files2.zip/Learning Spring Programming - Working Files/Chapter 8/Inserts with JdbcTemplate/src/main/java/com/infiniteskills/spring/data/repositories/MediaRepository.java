package com.infiniteskills.spring.data.repositories;

import com.infiniteskills.spring.data.entities.Media;

public interface MediaRepository extends Repo<Media>{

}
