package com.infiniteskills.spring.data.repositories;

import com.infiniteskills.spring.data.entities.Rental;

public interface RentalRepository extends Repo<Rental> {

}
