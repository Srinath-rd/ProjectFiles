package com.infiniteskills.spring.data.repositories;

import com.infiniteskills.spring.data.entities.Rental;

public class RentalRepositoryImpl implements RentalRepository{

	public void insert(Rental entity) {
		// TODO Auto-generated method stub
		
	}

	public void update(Rental entity) {
		// TODO Auto-generated method stub
		
	}

	public void delete(Rental entity) {
		// TODO Auto-generated method stub
		
	}

	public Rental findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

}
