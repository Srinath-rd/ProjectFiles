package com.infiniteskills.spring;

public interface AccessibleBeanName {

	public String getBeanName();
}
