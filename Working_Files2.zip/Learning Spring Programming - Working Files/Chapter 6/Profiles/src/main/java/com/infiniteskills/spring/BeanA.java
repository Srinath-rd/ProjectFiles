package com.infiniteskills.spring;

public class BeanA {

	private String configParameter;

	public String getConfigParameter() {
		return configParameter;
	}

	public void setConfigParameter(String configParameter) {
		this.configParameter = configParameter;
	}
	
}
